import Rotas from './components/rotas';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Home from './components/Home';
import Imperio from './components/Imperio';
import Naves from './components/Naves';
import Universo from './components/Universo';

const Tab = createBottomTabNavigator();

function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator>
        <Tab.Screen name="Home" component={Home} />
        <Tab.Screen name="Imperio" component={Imperio} />
        <Tab.Screen name="Naves" component={Naves} />
        <Tab.Screen name="Universo" component={Universo} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

export default App;
