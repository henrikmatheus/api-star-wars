import React from 'react';
import {View,Text,StyleSheet,Button,Image,ScrollView,Image1} from 'react-native';
import {useNavigation} from '@react-navigation/native';

function Universo() {
  const navigation = useNavigation();
  
  return(
    <ScrollView contentContainerStyle={estilo.container}>
    <View style={estilo.container}>
    <Image style={estilo.img} source={require('../assets/universo.jpg')} />
    <Text style={estilo.texto}>O universo de Star Wars é um vasto e fictício cenário espacial criado por George Lucas. É um dos universos de ficção científica mais reconhecíveis e amados da cultura pop. Aqui está um resumo sobre o universo de Star Wars:

Galáxia Distante: Star Wars se passa em uma galáxia muito, muito distante, que é habitada por diversas espécies alienígenas, civilizações e culturas. A galáxia é dividida em setores, sistemas estelares e planetas, cada um com sua própria história e características únicas.

A Força: A Força é uma energia mística que permeia o universo de Star Wars e concede poderes especiais a certos indivíduos. Existem duas polaridades principais da Força: o lado luminoso, representado pelos Jedi, e o lado sombrio, representado pelos Sith. A Força desempenha um papel central na narrativa de Star Wars.

Jedi e Sith: Os Jedi são uma ordem de guerreiros que usam a Força para manter a paz na galáxia. Eles são treinados em habilidades como telecinesia e telepatia. Os Sith, por outro lado, usam a Força para buscar poder pessoal e dominar os outros. A luta entre Jedi e Sith é um conflito recorrente na saga.

Império Galáctico: O Império Galáctico, liderado pelo Imperador Palpatine, é uma ditadura autoritária que busca controlar toda a galáxia. Ele é o principal antagonista na trilogia original de Star Wars, e sua opressão é central na história.

Planetas Icônicos: Star Wars apresenta uma variedade de planetas memoráveis, como Tatooine, um deserto árido; Hoth, um planeta gelado; Endor, lar dos Ewoks; e Coruscant, uma cidade-planeta coberta por arranha-céus.
O universo de Star Wars é um rico e cativante cenário de ficção científica que cativou o público por décadas, explorando temas universais de bem e mal, esperança e heroísmo, e aventura épica em uma galáxia muito distante.
    </Text>
    
    <Button title="Voltar" onPress={() => navigation.goBack()} />
    
    </View>
    </ScrollView>
  )
}
export default Universo;

const estilo = StyleSheet.create({
  container:{
    flex:1,
},
   texto:{
    fontSize:18,
    textAlign:'justify',
    margin:15,
   },

   img:{
    width: 300,
    height: 200, 
    borderRadius: 5,
    resizeMode: 'center'
  }
})