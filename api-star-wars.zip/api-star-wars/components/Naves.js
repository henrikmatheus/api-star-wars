import React from 'react';
import {View,Text,StyleSheet,Button,Image,ScrollView,Image1} from 'react-native';
import {useNavigation} from '@react-navigation/native';

function Naves() {
  const navigation = useNavigation();
  
  return(
    <ScrollView contentContainerStyle={estilo.container}>
    <View style={estilo.container}>
    <Image style={estilo.img} source={require('../assets/nave.jpg')} />
    <Text style={estilo.texto}>TIE Fighters: Essas naves de combate são usadas pelo Império Galáctico. Os TIE Fighters são conhecidos por sua agilidade, mas têm pouca blindagem e armamento.

X-wing: A nave de combate principal da Aliança Rebelde, conhecida por sua versatilidade e capacidade de ataque. Ela possui asas que se abrem em forma de "X" durante o combate.

Millennium Falcon: A icônica nave de Han Solo e Chewbacca. É uma nave cargueira altamente modificada, conhecida por sua velocidade e resistência. A Millennium Falcon desempenha um papel crucial na destruição da Estrela da Morte.

Estrela da Morte: Uma estação espacial colossal e móvel construída pelo Império. É equipada com um super laser capaz de destruir planetas inteiros. A primeira Estrela da Morte é destruída na batalha de Yavin, e uma segunda é destruída na batalha de Endor.

Slave I: A nave de Boba Fett, um famoso caçador de recompensas. Ela é conhecida por sua forma única e suas habilidades de rastreamento.

Nave de Boba Fett: Uma variante da Slave I, usada por Jango Fett, o pai de Boba Fett. Ela serviu como base de design para a Slave I.

Imperial Star Destroyer: Naves capitais usadas pelo Império. Elas são formidáveis e intimidadoras, com uma ampla variedade de armas.
     Nave de Luke Skywalker: Em diferentes momentos, Luke Skywalker pilota diversas naves, incluindo a X-wing e a T-65B X-wing.

Nave de Anakin Skywalker: Antes de se tornar Darth Vader, Anakin Skywalker pilota uma nave chamada de "Estrela da Liberdade" (ou "Negociador"), que é uma nave de transporte Jedi.

Naves Espaciais Únicas: Além das naves mencionadas, existem muitas outras naves únicas e memoráveis em Star Wars, como a nave de Lando Calrissian, o Lobo Solitário, e a nave pessoal da Princesa Leia, a Tantive IV.

Naves nas Novas Mídias: Star Wars continuou a expandir seu universo de naves em várias mídias, apresentando novos designs, como as naves da Primeira Ordem na trilogia sequela.

As naves em Star Wars são mais do que apenas veículos; elas são parte integrante da estética e da mitologia da franquia. Cada nave tem sua própria história e personalidade, e muitas vezes desempenham um papel crucial nas aventuras dos personagens.






    </Text>
    
    <Button title="Voltar" onPress={() => navigation.goBack()} />
    
    </View>
    </ScrollView>
  )
}
export default Naves;

const estilo = StyleSheet.create({
  container:{
    flex:1,
},
   texto:{
    fontSize:18,
    textAlign:'justify',
    margin:15,
   },

   img:{
    width: 300,
    height: 200, 
    borderRadius: 5,
    resizeMode: 'center'
  }
})