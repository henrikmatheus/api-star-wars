import React from 'react';
import {View,Text,StyleSheet,Button} from 'react-native';
import {useNavigation} from '@react-navigation/native';


function Home() {
  const navigation = useNavigation();

  function irImperio() {
    navigation.navigate('Imperio');
    }
  function irNaves() {
    navigation.navigate('Naves');
  }
  function irUniverso() {
    navigation.navigate('Universo');
  }

  return(
    <View style={estilo.container}>

    
    <Text style={estilo.titulo}>Star Wars</Text>
    <Text style={estilo.introducao}>Star Wars ocorre em uma galáxia fictícia com diversas espécies, planetas, e civilizações. A galáxia está dividida entre o lado luminoso (Jedi) e o lado sombrio (Sith) da Força, uma energia mística que concede habilidades especiais a certos indivíduos. O herói central da trilogia original, que se torna um Jedi e desempenha um papel fundamental na luta contra o Império Galáctico.
    Star Wars aborda temas como o conflito entre o bem e o mal, redenção, heroísmo, e a jornada do herói.Star Wars continua a crescer com novos projetos, incluindo séries de TV, filmes, e parques temáticos. A franquia também abriu discussões sobre mitologia, ética, política e religião no contexto de uma galáxia distante.

Star Wars é uma das franquias mais influentes e duradouras da história do entretenimento, e sua narrativa épica continua a cativar gerações de fãs em todo o mundo.
    </Text>
     <Button title="Imperio" onPress={irImperio} />
     <Button title="Naves" onPress={irNaves} />
     <Button title="Universo" onPress={irUniverso} />
    </View>
  )
}
export default Home;

const estilo = StyleSheet.create({
  container:{
    flex:1,
     },
  introducao:{
    fontSize:18,
    textAlign:'justify',
    margin:15,
  },
  titulo:{
    marginTop:30,
    marginBottom:30,
    fontSize:30,
    color:'black',
    fontWeight:'bold',
  },
})