import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';


import Home from './Home';
import Arbela from './Imperio';
import Maratona from './Naves';
import Poitiers from './Universo';

const Tab = createBottomTabNavigator();

function Rotas() {
  return(
    <Tab.Navigator>

     <Tab.Screen
     name="Home"
     component={Home}/>

     <Tab.Screen
     name="Imperio"
     component={Maratona}/>

     <Tab.Screen
     name="Naves"
     component={Arbela}/>

     <Tab.Screen
     name="Poitiers"
     component={Poitiers}/>

    </Tab.Navigator>
  );
}
export default createBottomTabNavigator();