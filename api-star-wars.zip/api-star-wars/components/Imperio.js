import React from 'react';
import {View,Text,StyleSheet,Button,Image,ScrollView,Image1} from 'react-native';
import {useNavigation} from '@react-navigation/native';

function Imperio() {
  const navigation = useNavigation();
  
  return(
    <ScrollView contentContainerStyle={estilo.container}>
    <View style={estilo.container}>
    <Image style={estilo.img} source={require('../assets/imperio.jpg')} />
    <Text style={estilo.texto}>O Império Galáctico é fundado pelo Imperador Palpatine, também conhecido como Darth Sidious, e seu aprendiz, Darth Vader (anteriormente conhecido como Anakin Skywalker). Eles consolidam seu poder após as Guerras Clônicas, que ocorreram entre a República Galáctica e a Confederação dos Sistemas Independentes. O Império é uma ditadura autoritária que busca controlar toda a galáxia. Sua ideologia central é o domínio absoluto do poder e a supressão de qualquer forma de oposição. Eles promovem valores como ordem, disciplina e lealdade total ao Império.
    O Império possui uma vasta máquina militar, incluindo gigantescas naves de guerra, como os Destróieres Estelares, e exércitos de soldados imperiais, como os Stormtroopers. Eles também têm à sua disposição armas letais, como os Tie Fighters e a Estrela da Morte, uma estação espacial capaz de destruir planetas inteiros.O Imperador Palpatine é o líder supremo do Império, governando com mão de ferro. Seu aprendiz, Darth Vader, é o enforcer do Império, responsável por eliminar qualquer ameaça à sua dominação.
    A Aliança Rebelde é formada como um grupo de resistência contra o Império. Liderada por figuras como a Princesa Leia, Luke Skywalker e Han Solo, a Aliança luta pela restauração da liberdade na galáxia e pela derrocada do Império.
    </Text>
    
    <Button title="Voltar" onPress={() => navigation.goBack()} />
    
    </View>
    </ScrollView>
  )
}
export default Imperio;

const estilo = StyleSheet.create({
  container:{
    flex:1,
},
   texto:{
    fontSize:18,
    textAlign:'justify',
    margin:15,
   },

   img:{
    width: 300,
    height: 200, 
    borderRadius: 5,
    resizeMode: 'center'
  }
})